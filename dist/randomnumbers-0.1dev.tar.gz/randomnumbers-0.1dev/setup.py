from distutils.core import setup

setup(
    name='randomnumbers',
    version='0.1dev',
    packages=['randomnumbers',],
    license='Full freedom to distribute and use for commerical and non-commercial reasons',
    long_description=open('README.md').read(),
    test_suite='nose.collector',
    tests_require=['nose'],
    install_requires=['numpy', 'nose', 'pandas']
)