normal = ["normal", "norm"]
poisson = ["poisson", "poiss"]
binomial = ["binomial", "binom"]
default_digits = 3