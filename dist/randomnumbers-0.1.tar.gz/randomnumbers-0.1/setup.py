from distutils.core import setup

setup(
    name='randomnumbers',
    version='0.1',
    packages=['randomnumbers',],
    license='Full freedom to distribute and use for commerical and non-commercial reasons',
    long_description=open('README.txt').read(),
    test_suite='nose.collector',
    tests_require=['nose'],
    install_requires=['numpy', 'nose', 'pandas'],
    author='Alfie Smith',
    author_email='alfiex1994@gmail.com',
    url='NA'

)
